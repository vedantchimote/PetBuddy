export const environment = {
  production: true,
  baseurl: 'https://yourpetbuddy.tech/',

  imagepath: 'https://yourpetbuddy.tech/uploads/',

  onesignalkey: '889fc27e-7782-4e47-b1d3-9e39193c6917', // For user push notification

  firebasekey: 'AAAAk8oSX18:APA91bFvvyltjSuRBxviwHPFfJDsCSOOs6sJHkcb-ynINpAymXdv_r73kCnB4y9VGwGCF0rOUxonxTSVLDSo4q3jjoN5zx31jU-UJOK51egVXwWnT4ZEYB9tuCj8fgUmXrHKOv8r0kNM', // For user push notification

  developer_website: 'https://yourpetbuddy.tech/',

  // fb_profile: 'fb://profile/xxxxxxxxxxxxxxxxx', // After order user can review us on FB

  mobileprefix: '+91', // For whatsapp messages

  playstore: '',

  appstore: '',

  iosrateandreview: '',

  app_share_text: 'Your Pets Buddy',

  androidappid: 'com.yourpetbuddy.tech',

  iosappid: '',

  appname: 'Pet Buddy',

  storage_prefix: 'yourpetbuddy'
};
