import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookbuffet',
  templateUrl: './bookbuffet.page.html',
  styleUrls: ['./bookbuffet.page.scss'],
})
export class BookbuffetPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
